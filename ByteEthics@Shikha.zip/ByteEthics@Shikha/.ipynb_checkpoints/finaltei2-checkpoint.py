import os
import pandas as pd
import spacy
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from wordcloud import WordCloud
import matplotlib.pyplot as plt

# Specify the directory path containing the text files
directory_path = "/Users/shikha/desktop/textfiles"

# Load the spaCy model for English
nlp = spacy.load('en_core_web_sm')

def preprocess_text(text):
    """Preprocess a single text document."""
    doc = nlp(text)
    filtered_tokens = [token.lemma_.lower() for token in doc if not token.is_stop 
                       and token.is_alpha and token.pos_ in ['NOUN', 'ADJ', 'VERB']
                       and token.ent_type_ not in ['LOC', 'PERSON', 'ORG', 'TIME', 'QUANTITY', 'MONEY', 'DATE']]
    return ' '.join(filtered_tokens)

def read_texts_and_titles(directory_path):
    """Read text files from the specified directory, preprocess them, and extract titles."""
    preprocessed_texts = []
    titles = []
    for filename in os.listdir(directory_path):
        if filename.endswith('.txt'):
            file_path = os.path.join(directory_path, filename)
            with open(file_path, 'r', encoding='utf-8') as file:
                text = file.read()
            preprocessed_texts.append(preprocess_text(text))
            # Use the filename without extension as the document title
            titles.append(os.path.splitext(filename)[0])
    return preprocessed_texts, titles

preprocessed_texts, document_titles = read_texts_and_titles(directory_path)

# Vectorize the preprocessed texts

vectorizer = TfidfVectorizer(max_df=0.6, min_df=2)
tfidf_matrix = vectorizer.fit_transform(preprocessed_texts)
feature_names = vectorizer.get_feature_names_out()

# Retrieve and store the top 20 words for each document
top_n = 20
for i, row in enumerate(tfidf_matrix):
    row = row.toarray().ravel()
    top_indices = np.argsort(row)[-top_n:]
    top_features = [(feature_names[index], row[index]) for index in top_indices]
    top_features.sort(key=lambda x: x[1], reverse=True)
    
    # Print top words for verification
    print(f"Top 20 Words for {document_titles[i]}:\n", pd.DataFrame(top_features, columns=['Word', 'TF-IDF Score']), "\n")
    
    # Save to CSV
    
    filename = os.path.join(directory_path, f"{document_titles[i]}_top_words.csv")
    pd.DataFrame(top_features, columns=['Word', 'TF-IDF Score']).to_csv(filename, index=False)

# Calculate cosine similarity and find the top 3 most similar documents for each document

similarity_matrix = cosine_similarity(tfidf_matrix)
top_n_similar_docs = 3

for i, similarity_scores in enumerate(similarity_matrix):
    top_indices = np.argsort(similarity_scores)[-top_n_similar_docs-1:-1]  # Exclude the document itself
    top_similar_docs = [(document_titles[index], similarity_scores[index]) for index in top_indices]
    top_similar_docs.sort(key=lambda x: x[1], reverse=True)
    
    # Print similar documents for verification
    print(f"Top 3 Similar Documents for {document_titles[i]}:\n", pd.DataFrame(top_similar_docs, columns=['Document', 'Similarity']), "\n")
    
    # Save to CSV
    filename = os.path.join(directory_path, f"{document_titles[i]}_similar_docs.csv")
    pd.DataFrame(top_similar_docs, columns=['Document', 'Similarity']).to_csv(filename, index=False)

# Sum TF-IDF scores for each word across all documents
summed_tfidf = np.sum(tfidf_matrix, axis=0)
summed_tfidf = np.squeeze(np.asarray(summed_tfidf))  # Convert from matrix to array

# Map feature names to their summed TF-IDF scores
word_scores = {feature_names[i]: summed_tfidf[i] for i in range(len(feature_names))}

# Generate a word cloud from the aggregated scores
wordcloud = WordCloud(width=800, height=800, background_color='white').generate_from_frequencies(word_scores)

# Display the word cloud
plt.figure(figsize=(8, 8), facecolor=None)
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.title("Word Cloud from All Documents")
plt.show()

# Optionally, save the word cloud image
wordcloud.to_file(os.path.join(directory_path, "all_documents_wordcloud.png"))


import seaborn as sns
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

# Number of clusters
num_clusters = 5  # Adjust to your specific needs

# Perform clustering on the TF-IDF data
km = KMeans(n_clusters=num_clusters)
km.fit(tfidf_matrix)
clusters = km.labels_

# Sort the documents by cluster and by similarity within clusters
sorted_indices = np.argsort(clusters)
sorted_similarity_matrix = similarity_matrix[sorted_indices][:, sorted_indices]

# Create a DataFrame from the sorted similarity matrix for easier plotting
df_similarity_sorted = pd.DataFrame(sorted_similarity_matrix)

# Plotting the clustered heatmap
plt.figure(figsize=(10, 10))
sns.heatmap(df_similarity_sorted, cmap='viridis', xticklabels=False, yticklabels=False)
plt.title('Clustered Heatmap of Document Cosine Similarity')

# Save the figure
output_file_path = os.path.join(directory_path, "clustered_heatmap.png")  # Specify the output file path
plt.savefig(output_file_path, dpi=300, bbox_inches='tight')

# Show the plot (this will display the plot inline if you're using Jupyter Notebook)
plt.show()

# If you're running this in a standalone Python script and don't want to display the plot,
# you can comment out plt.show() and just save the figure.


