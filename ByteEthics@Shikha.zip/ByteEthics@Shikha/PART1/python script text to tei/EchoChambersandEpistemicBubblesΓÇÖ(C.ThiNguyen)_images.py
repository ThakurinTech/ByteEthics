from bs4 import BeautifulSoup as bs
import re

file_path = "/Users/shikha/Desktop/Echo.txt" 

def create_tei_document(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        document_text = file.read()

    # TEI header with metadata
    tei_header = """
    <teiHeader>
        <fileDesc>
            <titleStmt>
                <title>Retweeting: its Linguistic and Epistemic Value</title>
                <author>Neri Marsili</author>
            </titleStmt>
            <publicationStmt>
                <publisher>Unknown Publisher</publisher>
                <date>Unknown Date</date>
                <pubPlace>Unknown Place</pubPlace>
            </publicationStmt>
            <sourceDesc>
                <bibl>Article or Chapter Details.</bibl>
            </sourceDesc>
        </fileDesc>
    </teiHeader>
    """

    # Initialize TEI body, processing paragraphs
    paragraphs = re.split(r'\n\n+', document_text) 
    tei_body = "<text><body>"
    for paragraph in paragraphs:
        clean_paragraph = paragraph.strip().replace('\n', ' ')
        if clean_paragraph:
            tei_body += f"<p>{clean_paragraph}</p>"
    tei_body += "</body></text>"

    # Combine header and body into one TEI document
    tei_document = f'<?xml version="1.0" encoding="UTF-8"?><TEI xmlns="http://www.tei-c.org/ns/1.0">{tei_header}{tei_body}</TEI>'

    # Beautify and save the TEI document
    soup = bs(tei_document, 'xml')
    output_file_path = file_path.replace('.txt', '_TEI.xml')
    with open(output_file_path, 'w', encoding='utf-8') as file:
        file.write(soup.prettify())

    return output_file_path

# Execute the function to convert and save the document in TEI format
output_path = create_tei_document(file_path)
print(f"TEI document has been created at {output_path}")
