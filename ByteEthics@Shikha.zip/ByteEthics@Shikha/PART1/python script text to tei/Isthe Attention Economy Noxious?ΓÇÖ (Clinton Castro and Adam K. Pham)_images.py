import re
from bs4 import BeautifulSoup as bs

file_path='/Users/shikha/Desktop/attention.txt'

def read_document(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

def apply_tei_tags(document_text):
    tei_structure = "<text><body>"
    sections = re.split(r'\n(?=\d+\.\d+\s)', document_text)  
    for section in sections:
        section_title_match = re.match(r'(\d+\.\d+)\s(.+)', section)
        if section_title_match:
            section_number, section_title = section_title_match.groups()
            section_body = section[section_title_match.end():].strip()
            tei_structure += f"<div><head>{section_title}</head>"
            paragraphs = re.split(r'\n\n+', section_body)
            for paragraph in paragraphs:
                tei_structure += f"<p>{paragraph.strip()}</p>"
            tei_structure += "</div>"
    tei_structure += "</body></text>"
    return tei_structure

def create_tei_header(title, author):
    tei_header = f"""
    <teiHeader>
        <fileDesc>
            <titleStmt>
                <title>{title}</title>
                <author>{author}</author>
            </titleStmt>
            <publicationStmt>
                <publisher>Philosophers' Imprint</publisher>
                <date>2020-05</date>
            </publicationStmt>
            <sourceDesc>
                <p>Analysis of the negative impacts of the attention economy.</p>
            </sourceDesc>
        </fileDesc>
    </teiHeader>
    """
    return tei_header

# Adjust these paths and details for your specific document and environment
title = "Is the Attention Economy Noxious?"
author = "Clinton Castro & Adam K. Pham"


document_text = read_document(file_path)
tei_body = apply_tei_tags(document_text)
tei_header = create_tei_header(title, author)
tei_document = f'<?xml version="1.0" encoding="UTF-8"?><TEI xmlns="http://www.tei-c.org/ns/1.0">{tei_header}{tei_body}</TEI>'

soup = bs(tei_document, 'xml')
output_file_path = '/Users/shikha/Desktop/dcorpus/attenstion.xml'  
with open(output_file_path, 'w', encoding='utf-8') as file:
    file.write(soup.prettify())

print(f"TEI document has been created at {output_file_path}")
