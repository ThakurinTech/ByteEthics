from bs4 import BeautifulSoup as bs
import re

file_path="/Users/shikha/Desktop/Augmented.txt"

def create_tei_document(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        document_text = file.read()

    # Extracting document metadata
    title = "Augmented Reality, Augmented Ethics: Who has the Right to Augment a Particular Physical Space?"
    author = "Erica Neely"

    # TEI header
    tei_header = f"""
    <teiHeader>
        <fileDesc>
            <titleStmt>
                <title>{title}</title>
                <author>{author}</author>
            </titleStmt>
            <publicationStmt>
                <publisher>Unknown</publisher>
                <date>Unknown</date>
            </publicationStmt>
            <sourceDesc>
                <p>Analysis of ethical implications of augmented reality technologies.</p>
            </sourceDesc>
        </fileDesc>
    </teiHeader>
    """

    # Initialize TEI body
    tei_body = "<text><body>"

    # Identifying and processing sections
    sections = re.split(r'\n(?=[A-Z])', document_text) 
    for section in sections:
        header_match = re.match(r'([A-Z].+)', section)
        if header_match:
            section_title = header_match.group(1)
            section_body = section[header_match.end():].strip()
            tei_body += f"<div><head>{section_title}</head>"

            paragraphs = re.split(r'\n\n+', section_body)
            for paragraph in paragraphs:
                tei_body += f"<p>{paragraph.strip()}</p>"
            tei_body += "</div>"

    tei_body += "</body></text>"

    # Combining header and body
    tei_document = f'<?xml version="1.0" encoding="UTF-8"?><TEI xmlns="http://www.tei-c.org/ns/1.0">{tei_header}{tei_body}</TEI>'

    # Beautifying and saving the TEI document
    soup = bs(tei_document, 'xml')
    output_file_path = file_path.replace('.txt', '_TEI.xml')
    with open(output_file_path, 'w', encoding='utf-8') as file:
        file.write(soup.prettify())

    print(f"TEI document has been created at {output_file_path}")


create_tei_document(file_path)
