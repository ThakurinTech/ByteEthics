import re
from bs4 import BeautifulSoup as bs
from datetime import datetime

file_path = "/Users/shikha/desktop/dcorpus/Identifying.txt"

def read_document(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read()
    return content

def apply_tei_tags(document_text):
    tei_structure = "<text>"
    
    abstract_match = re.search(r'Abstract:(.*?)\n\n', document_text, re.S)
    if abstract_match:
        abstract = abstract_match.group(1).strip()
        tei_structure += f"<front><div type='abstract'><p>{abstract}</p></div></front>"
        document_text = document_text[abstract_match.end():] 
    else:
        print("No abstract found, proceeding without it.")
    
    tei_structure += "<body>"
    
    sections = re.split(r'\n(?=\d+\.\s)', document_text)  
    for section in sections:
        if section.strip():
            head_match = re.match(r'(\d+\.\s)(.*?)\n', section)
            if head_match:
                section_title = head_match.group(2).strip()
                section_body = section[head_match.end():].strip()
                tei_structure += f"<div><head>{section_title}</head>"
                paragraphs = re.split(r'\n\n+', section_body)
                for paragraph in paragraphs:
                    tei_structure += f"<p>{paragraph.strip()}</p>"
                tei_structure += "</div>"
    
    tei_structure += "</body></text>"
    return tei_structure

def create_tei_document(body_content):
    tei_header = """
    <teiHeader>
        <fileDesc>
            <titleStmt>
                <title>Identifying and Defending the Hard Core of Virtue Ethics</title>
                <author>Mark Alfano</author>
            </titleStmt>
            <publicationStmt>
                <publisher>Placeholder Publisher</publisher>
                <date>Placeholder Date</date>
            </publicationStmt>
            <sourceDesc>
                <p>Placeholder Source Description</p>
            </sourceDesc>
        </fileDesc>
    </teiHeader>
    """
    return f'<?xml version="1.0" encoding="UTF-8"?><TEI xmlns="http://www.tei-c.org/ns/1.0">{tei_header}{body_content}</TEI>'


document_text = read_document(file_path)
tei_body = apply_tei_tags(document_text)
tei_document = create_tei_document(tei_body)

soup = bs(tei_document, 'xml')
output_file_path = '/Users/shikha/desktop/dcorpus/identify.xml'  
with open(output_file_path, 'w', encoding='utf-8') as file:
    file.write(soup.prettify())

print(f"TEI document has been created at {output_file_path}")













