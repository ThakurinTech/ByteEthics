from bs4 import BeautifulSoup as bs
import re

file_path="/Users/shikha/Desktop/Themes.txt"

def create_tei_document(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        document_text = file.read()

    # Define metadata
    title = "Themes: The most harmful or menacing changes in digital life that are likely by 2035"
    authors = ["Janna Anderson", "Lee Rainie"]
    publisher = "Pew Research Center"

    # TEI header
    tei_header = f"""
    <teiHeader>
        <fileDesc>
            <titleStmt>
                <title>{title}</title>
                {''.join([f'<author>{author}</author>' for author in authors])}
            </titleStmt>
            <publicationStmt>
                <publisher>{publisher}</publisher>
                <date>2023</date>
            </publicationStmt>
            <sourceDesc>
                <p>Comprehensive analysis of potential negative impacts of digital advancements by 2035.</p>
            </sourceDesc>
        </fileDesc>
    </teiHeader>
    """

    # Initialize TEI body
    tei_body = "<text><body>"

    # Process sections
    sections = re.split(r'\n(?=Harms related to)', document_text) 
    for section in sections:
        header_match = re.match(r'(Harms related to .+)', section)
        if header_match:
            section_title = header_match.group(1)
            section_body = section[header_match.end():].strip()
            tei_body += f"<div><head>{section_title}</head>"

            paragraphs = re.split(r'\n\n+', section_body)
            for paragraph in paragraphs:
                tei_body += f"<p>{paragraph.strip()}</p>"
            tei_body += "</div>"

    tei_body += "</body></text>"

    # Combine header and body
    tei_document = f'<?xml version="1.0" encoding="UTF-8"?><TEI xmlns="http://www.tei-c.org/ns/1.0">{tei_header}{tei_body}</TEI>'

    # Beautify and save
    soup = bs(tei_document, 'xml')
    output_file_path = file_path.replace('.txt', '_TEI.xml')
    with open(output_file_path, 'w', encoding='utf-8') as file:
        file.write(soup.prettify())

    print(f"TEI document has been created at {output_file_path}")


create_tei_document(file_path)
