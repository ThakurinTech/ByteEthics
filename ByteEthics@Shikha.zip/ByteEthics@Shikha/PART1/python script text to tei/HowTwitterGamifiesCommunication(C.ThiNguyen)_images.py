import re
from bs4 import BeautifulSoup as bs
from datetime import datetime

file_path = "/Users/shikha/desktop/dcorpus/‘HowTwitterGamifiesCommunication’(C.ThiNguyen)_images.txt"

def read_document(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

def apply_tei_tags(text):
    # Wrap each paragraph in <p> tags
    paragraphs = text.split('\n\n')  
    wrapped_paragraphs = [f'<p>{paragraph.strip()}</p>' for paragraph in paragraphs if paragraph.strip()]
    tei_body_content = '\n'.join(wrapped_paragraphs)
    return f'<text><body>{tei_body_content}</body></text>'

def create_tei_header(title, author):
    return f"""
<teiHeader>
    <fileDesc>
        <titleStmt>
            <title>{title}</title>
            <author>{author}</author>
        </titleStmt>
        <publicationStmt>
            <p>[Publisher Information]</p>
        </publicationStmt>
        <sourceDesc>
            <p>[Source Description]</p>
        </sourceDesc>
    </fileDesc>
</teiHeader>
"""

# Define main document details
title = "How Twitter Gamifies Communication"
author = "C. Thi Nguyen"


document_text = read_document(file_path)
tei_body = apply_tei_tags(document_text)
tei_header = create_tei_header(title, author)
tei_document = f'<?xml version="1.0" encoding="UTF-8"?><TEI xmlns="http://www.tei-c.org/ns/1.0">{tei_header}{tei_body}</TEI>'

# Beautify and save the TEI document
soup = bs(tei_document, 'xml')
output_file_path = '/Users/shikha/desktop/dcorpus/twitter.tei.xml' 
with open(output_file_path, 'w', encoding='utf-8') as file:
    file.write(soup.prettify())

print(f"TEI document has been created at {output_file_path}")







