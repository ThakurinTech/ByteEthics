from bs4 import BeautifulSoup as bs
import re

input_file_path = "/Users/shikha/Desktop/ethics.txt"
output_file_path = "/Users/shikha/Desktop/ethics.xml"


def create_tei_document(input_file_path, output_file_path):
    with open(input_file_path, 'r', encoding='utf-8') as file:
        document_text = file.read()

    # Basic structure for TEI document
    tei_header = f"""
    <teiHeader>
        <fileDesc>
            <titleStmt>
                <title>The Oxford Handbook of Digital Ethics</title>
                <author>Edited by Carissa Véliz</author>
            </titleStmt>
            <publicationStmt>
                <publisher>Oxford University Press</publisher>
                <pubPlace>Oxford, UK</pubPlace>
                <date>2023</date>
            </publicationStmt>
            <sourceDesc>
                <p>This publication is a comprehensive collection of articles addressing the multifaceted ethical considerations in the digital age, ranging from social media ethics to the moral implications of AI.</p>
            </sourceDesc>
        </fileDesc>
    </teiHeader>
    """
    
    tei_body = "<text><body>"
    
   
    parts = re.split(r'(?=PART [IVXLCDM]+\.)', document_text)
    
    for part in parts:
       
        chapters = re.split(r'(?=CHAPTER\s+\d+)', part)  
        for chapter in chapters:
            chapter_title_search = re.search(r'CHAPTER (\d+)', chapter)
            chapter_number = chapter_title_search.group(1) if chapter_title_search else ""
            chapter_title = f"CHAPTER {chapter_number}" if chapter_number else ""
            chapter_content = chapter[chapter_title_search.end():].strip() if chapter_title_search else chapter.strip()
            paragraphs = re.split(r'\n{2,}', chapter_content) 
            
            tei_body += f"<div type='chapter'><head>{chapter_title}</head>"
            for paragraph in paragraphs:
                tei_body += f"<p>{paragraph.strip()}</p>"
            tei_body += "</div>"

    tei_body += "</body></text>"

    tei_document = f'<?xml version="1.0" encoding="UTF-8"?><TEI xmlns="http://www.tei-c.org/ns/1.0">{tei_header}{tei_body}</TEI>'

    # Save TEI document
    soup = bs(tei_document, 'xml')
    with open(output_file_path, 'w', encoding='utf-8') as file:
        file.write(soup.prettify())

create_tei_document(input_file_path, output_file_path)



