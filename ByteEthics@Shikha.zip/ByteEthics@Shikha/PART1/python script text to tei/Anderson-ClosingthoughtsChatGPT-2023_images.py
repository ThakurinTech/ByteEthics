import re
from bs4 import BeautifulSoup as bs
from xml.etree.ElementTree import Element, SubElement, tostring
from xml.dom.minidom import parseString

file_path = "/Users/shikha/desktop/dcorpus/Anderson-ClosingthoughtsChatGPT-2023_images.txt"

# Metadata 
title = "As AI Spreads, Experts Predict the Best and Worst Changes in Digital Life by 2035"
author = "Janna Anderson and Lee Rainie"

# Define the detailed TEI Header with the provided structure
tei_header = """
<teiHeader>
  <fileDesc>
    <titleStmt>
      <title>As AI Spreads, Experts Predict the Best and Worst Changes in Digital Life by 2035</title>
      <author>Janna Anderson and Lee Rainie</author>
    </titleStmt>
    <publicationStmt>
      <publisher>Pew Research Center</publisher>
      <date>2023</date>
      <availability>
        <p>Stable URL: https://www.jstor.org/stable/resrep57306.10</p>
      </availability>
    </publicationStmt>
  </fileDesc>
  <sourceDesc>
    <p>Report Part Title: Closing thoughts on ChatGPT and other steps in the evolution of humans, digital tools and systems by 2035</p>
  </sourceDesc>
</teiHeader>
"""

# Initialize the TEI body
tei_body = "<text><body>"


with open(file_path, 'r', encoding='utf-8') as file:
    content = file.read()
    paragraphs = content.split('\n\n')
    for para in paragraphs:
        if re.match(r'Report Part Title:|Report Title:|Report Subtitle:|Report Author\(s\):', para):
            tei_body += f'<div><head>{para}</head></div>'
        else:
            tei_body += f'<p>{para}</p>'

# Close the body and text tags
tei_body += "</body></text>"

# Combine the detailed header and body into one TEI document
tei = f'<?xml version="1.0" encoding="utf-8"?><TEI xmlns="http://www.tei-c.org/ns/1.0">{tei_header}{tei_body}</TEI>'

# Use BeautifulSoup to prettify the output
soup = bs(tei, "xml")


output_file_path = "/Users/shikha/desktop/dcorpus/ClosingthoughtsChatGPT2023.tei.xml"  
with open(output_file_path, "w", encoding='utf-8') as output_file:
    output_file.write(soup.prettify())

print(f"TEI file created at {output_file_path}")
