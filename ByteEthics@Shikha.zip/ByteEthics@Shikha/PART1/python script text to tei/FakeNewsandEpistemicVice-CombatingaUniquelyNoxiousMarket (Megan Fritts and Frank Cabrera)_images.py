import os
from bs4 import BeautifulSoup as bs
from datetime import datetime
import re

file_path = '/Users/shikha/Desktop/dcorpus/‘FakeNewsandEpistemicVice-CombatingaUniquelyNoxiousMarket’ (Megan Fritts and Frank Cabrera)_images.txt'

def read_document(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

def apply_tei_tags(text):
   
    text = re.sub(r'(\d+\.\s+)([^\n]+)', r'<div><head>\2</head>', text)
    text = re.sub(r'(<div><head>.+?</head>)', r'\1</div>', text)
    text = '<div>' + text + '</div>'  
    text = text.replace('Introduction', '<div type="introduction">', 1)  # Marked introduction
    text = re.sub(r'(\d+)\. (Conclusion)', r'<div type="conclusion">', text)  # Marked conclusion
    text = re.sub(r'Works Cited', r'<div type="references"><head>Works Cited</head>', text) + '</div>'  # Marked references
    return f'<text><body>{text}</body></text>'

def create_tei_header(title, authors):
    return f"""
<teiHeader>
    <fileDesc>
        <titleStmt>
            <title>{title}</title>
            <author>{' and '.join(authors)}</author>
        </titleStmt>
        <publicationStmt>
            <p>[Details about the publication]</p>
        </publicationStmt>
        <sourceDesc>
            <p>[Description of the source document]</p>
        </sourceDesc>
    </fileDesc>
</teiHeader>
"""

# Define main document details
title = "Fake News and Epistemic Vice: Combating a Uniquely Noxious Market"
authors = ["Megan Fritts", "Frank Cabrera"]


document_text = read_document(file_path)
tei_body = apply_tei_tags(document_text)
tei_header = create_tei_header(title, authors)
tei_document = f'<?xml version="1.0" encoding="UTF-8"?><TEI xmlns="http://www.tei-c.org/ns/1.0">{tei_header}{tei_body}</TEI>'

# Beautify and save the TEI document
soup = bs(tei_document, 'xml')
output_file_path = '/Users/shikha/desktop/dcorpus.fake.tei.xml'  # TODO
with open(output_file_path, 'w', encoding='utf-8') as file:
    file.write(soup.prettify())

print(f"TEI document has been created at {output_file_path}")


# Beautify and save the TEI document
soup = bs(tei_document, 'xml')
output_file_path = '/Users/shikha/desktop/dcorpus.fake.tei.xml'
with open(output_file_path, 'w', encoding='utf-8') as output_file:
    output_file.write(soup.prettify())

print(f"TEI document has been created at {output_file_path}")



