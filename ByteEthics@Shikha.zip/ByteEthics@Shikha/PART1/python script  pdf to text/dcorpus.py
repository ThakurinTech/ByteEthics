#Python File to covert pdf to txt


import os
from pdf2image import convert_from_path
import pytesseract
from PIL import Image

# Path to the directory containing PDF files
directory_path = "/Users/shikha/Desktop/dcorpus/pdf"  

# Set the path to the Tesseract command

pytesseract.pytesseract.tesseract_cmd = '/opt/homebrew/bin/tesseract'

def extract_images_from_pdf(pdf_path):
    """Extract images from PDF and save them in a directory."""
    filename = os.path.basename(pdf_path).replace(".pdf", "")
    images_dir = f"{filename}_images"
    if not os.path.exists(images_dir):
        os.makedirs(images_dir)
    
    # Convert PDF pages to images
    images = convert_from_path(pdf_path, dpi=300)
    for page_number, image in enumerate(images):
        image_path = f"{images_dir}/page-{page_number+1}.png"
        image.save(image_path, "PNG")

def run_ocr_on_images(images_dir):
    """Run OCR on extracted images and save the text output."""
    output_filepath = f"{images_dir}.txt"

    with open(output_filepath, "w", encoding="utf8") as output_file:
        for image_filename in sorted(os.listdir(images_dir)):
            if image_filename.endswith(".png"):
                image_path = os.path.join(images_dir, image_filename)
                print(f"Processing OCR for {image_path}...")
                text = pytesseract.image_to_string(Image.open(image_path))
                output_file.write(text + "\n\n")

# Iterate over all PDF files in the directory
for filename in os.listdir(directory_path):
    if filename.endswith(".pdf"):
        pdf_path = os.path.join(directory_path, filename)
        print(f"Processing file: {filename}")
        extract_images_from_pdf(pdf_path)
        base_name = os.path.basename(pdf_path).replace(".pdf", "")
        images_dir = f"{base_name}_images"
        run_ocr_on_images(images_dir)

print("OCR processing complete for all files.")