import fitz  # Import PyMuPDF

# Define the path 

pdf_file_path = "/Users/shikha/Desktop/Oxford.pdf"  
text_file_path = "/Users/shikha/Desktop//Oxford.txt"  

# Open the PDF file
doc = fitz.open(pdf_file_path)

# Open the text file for writing
with open(text_file_path, "w") as text_file:
    # Iterate through each page of the PDF
    for page_num in range(len(doc)):
        # Get the page
        page = doc.load_page(page_num)
        # Extract text from the page
        text = page.get_text()
        # Write the text to the file
        text_file.write(text)

# Close the PDF document
doc.close()

print(f"Text extracted and saved to {text_file_path}")
